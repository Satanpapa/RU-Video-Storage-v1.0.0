# RU Video Storage

Инструмент для хранения файлов на российских видеоплатформах (VK Видео и RuTube) в виде видео.

## 🎯 Возможности

- **Кодирование файлов в видео**: Конвертация любых файлов в lossless видео (FFV1/MKV)
- **Декодирование**: Восстановление оригинальных файлов из видео
- **Fountain коды (Wirehair)**: Избыточность и исправление ошибок
- **Шифрование**: Опциональное шифрование файлов (AES-256-GCM)
- **Поддержка платформ**: VK Видео и RuTube
- **Batch обработка**: Очередь файлов для пакетного кодирования
- **Progress tracking**: Отображение прогресса в реальном времени

## 🔧 Технические детали

### Архитектура

1. **Chunking**: Файлы разбиваются на чанки (по умолчанию 64KB)
2. **Fountain Codes**: Использование Wirehair для генерации избыточных пакетов
3. **CRC32**: Проверка целостности каждого чанка
4. **DCT Encoding**: Встраивание данных в частотную область (DCT коэффициенты)
5. **Video Encoding**: FFV1 кодек в MKV контейнере (4K, 30fps)

### Формат видео

- **Кодек**: FFV1 (lossless)
- **Контейнер**: MKV
- **Разрешение**: 3840x2160 (4K)
- **FPS**: 30
- **Цветовое пространство**: YUV444P

### Метаданные

В первые кадры видео встраиваются:
- Имя файла
- Размер файла
- Количество чанков
- CRC32 контрольная сумма
- Параметры кодирования
- Версия инструмента

## 📦 Установка

### Требования

- Python 3.9+
- FFmpeg 5.0+
- libsodium (для шифрования)

### Зависимости Python

```bash
pip install -r requirements.txt
```

Основные библиотеки:
- opencv-python (работа с видео)
- numpy (обработка данных)
- pycryptodome (шифрование)
- tqdm (progress bars)
- requests (загрузка/скачивание)

### Установка FFmpeg

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install ffmpeg
```

**macOS:**
```bash
brew install ffmpeg
```

**Windows:**
Скачайте с [ffmpeg.org](https://ffmpeg.org/download.html)

## 🚀 Использование

### CLI (Командная строка)

#### Кодирование файла

```bash
python -m ru_video_storage encode \
    --input document.pdf \
    --output video.mkv \
    --encrypt \
    --password mypassword123
```

#### Декодирование файла

```bash
python -m ru_video_storage decode \
    --input video.mkv \
    --output document.pdf \
    --password mypassword123
```

#### Загрузка на VK Видео

```bash
python -m ru_video_storage upload \
    --platform vk \
    --input video.mkv \
    --token YOUR_VK_TOKEN \
    --title "My Storage Video"
```

#### Загрузка на RuTube

```bash
python -m ru_video_storage upload \
    --platform rutube \
    --input video.mkv \
    --token YOUR_RUTUBE_TOKEN \
    --title "My Storage Video"
```

#### Скачивание с платформы

```bash
python -m ru_video_storage download \
    --platform vk \
    --video-id 123456789 \
    --output video.mkv \
    --token YOUR_VK_TOKEN
```

### Python API

```python
from ru_video_storage import VideoEncoder, VideoDecoder, VKUploader, RuTubeUploader

# Кодирование
encoder = VideoEncoder(
    input_file="document.pdf",
    output_file="video.mkv",
    encryption_password="mypass123"
)
encoder.encode()

# Декодирование
decoder = VideoDecoder(
    input_file="video.mkv",
    output_file="document_restored.pdf",
    decryption_password="mypass123"
)
decoder.decode()

# Загрузка на VK
uploader = VKUploader(access_token="YOUR_TOKEN")
video_id = uploader.upload(
    video_path="video.mkv",
    title="Storage Video",
    description="Encrypted storage"
)

# Загрузка на RuTube
uploader = RuTubeUploader(access_token="YOUR_TOKEN")
video_id = uploader.upload(
    video_path="video.mkv",
    title="Storage Video"
)
```

## 🔐 Безопасность

### Шифрование

- **Алгоритм**: AES-256-GCM
- **Ключ**: Производный от пароля через PBKDF2 (100,000 итераций)
- **Nonce**: 16 байт случайных данных для каждого чанка
- **Аутентификация**: GCM tag для проверки целостности

### Рекомендации

1. Используйте сильные пароли (16+ символов)
2. Не храните пароли в коде
3. Используйте переменные окружения для токенов
4. Регулярно обновляйте зависимости

## 📊 Производительность

### Скорость кодирования

- ~5-10 MB/s (зависит от CPU)
- Ускорение с многопоточностью (OpenMP)

### Коэффициент сжатия

- Видео файл ~1.5-2x больше оригинального файла
- Зависит от избыточности fountain кодов

### Надежность

- Восстановление файлов с потерей до 30% пакетов
- CRC32 проверка для обнаружения повреждений

## 🌐 API платформ

### VK Видео API

Документация: https://dev.vk.com/ru/method/video

Необходимые права доступа:
- `video` - для загрузки и скачивания видео

Получение токена:
1. Создайте приложение на https://vk.com/apps?act=manage
2. Получите access_token через OAuth

### RuTube API

Документация: https://rutube.ru/info/api/

Необходимые параметры:
- API ключ для загрузки видео
- Client ID и Secret для OAuth

Регистрация:
1. Зарегистрируйтесь на https://rutube.ru/
2. Создайте приложение в настройках разработчика
3. Получите API credentials

## 🛠️ Разработка

### Запуск тестов

```bash
pytest tests/ -v
```

### Структура проекта

```
ru-video-storage/
├── src/
│   ├── __init__.py
│   ├── encoder.py          # Кодирование файлов в видео
│   ├── decoder.py          # Декодирование видео в файлы
│   ├── fountain.py         # Wirehair fountain codes
│   ├── crypto.py           # Шифрование/дешифрование
│   ├── metadata.py         # Управление метаданными
│   ├── vk_uploader.py      # Загрузка на VK
│   ├── rutube_uploader.py  # Загрузка на RuTube
│   └── cli.py              # CLI интерфейс
├── tests/
│   ├── test_encoder.py
│   ├── test_decoder.py
│   └── test_uploaders.py
├── requirements.txt
├── setup.py
└── README.md
```

## ⚠️ Юридические вопросы

**ВАЖНО**: Использование видеоплатформ в качестве файлового хранилища может нарушать Terms of Service (ToS):

- **VK**: Запрещено использование для хранения не-видео контента
- **RuTube**: Аналогичные ограничения в правилах использования

**Риски**:
- Блокировка аккаунта
- Удаление видео
- Потеря данных

**Рекомендация**: Используйте только для образовательных целей и экспериментов.

## 📄 Лицензия

GPL-3.0 License - см. файл LICENSE

## 🤝 Вклад

Pull requests приветствуются! Для крупных изменений сначала откройте issue для обсуждения.

## 📞 Контакты

- Issues: https://github.com/yourusername/ru-video-storage/issues
- Email: your.email@example.com

## 🙏 Благодарности

Проект вдохновлен:
- [yt-media-storage](https://github.com/PulseBeat02/yt-media-storage) - оригинальная идея
- Brandon Li - концепция YouTube storage
- Wirehair fountain codes library

## 🔄 История версий

### v1.0.0 (2026-02-17)
- ✨ Первый релиз
- 🎥 Поддержка VK Видео и RuTube
- 🔐 AES-256 шифрование
- 🌊 Wirehair fountain codes
- 📊 CLI и Python API

---

**Disclaimer**: Этот проект создан исключительно в образовательных целях. Автор не несет ответственности за нарушение ToS платформ или потерю данных.
