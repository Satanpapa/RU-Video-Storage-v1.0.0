"""
Main entry point for running as module: python -m ru_video_storage
"""
from src.cli import cli

if __name__ == '__main__':
    cli()
